import 'dart:math';
import 'package:flutter/material.dart';
import 'engine.dart';
import 'board_draw.dart';
import 'match_info.dart';
import 'peer.dart';
import 'settings.dart';
import 'strings.dart';
import 'ui.dart';
import 'ai_glue.dart';
import 'ai_ui.dart';
import 'enter_fx.dart';

class GamePage extends StatefulWidget {
  final bool free;
  final MatchInfo? match;
  final bool mate;
  final bool strictInit;
  final AiPlan? ai;
  const GamePage({
    super.key,
    required this.free,
    this.match,
    this.mate = true,
    this.strictInit = false,
    this.ai,
  });

  @override
  State<GamePage> createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> with TickerProviderStateMixin {
  final game = Game();
  int? sr, sc;
  List<Move> hints = [];
  Move? last;
  bool lastCap = false;
  bool flip = false;
  bool strict = true;
  bool autoMate = true;
  bool devFree = false;
  bool devUsed = false;
  bool _aiThinking = false;
  int _aiGen = 0;
  bool lost = false;
  String? over;
  bool _recorded = false;
  late final AnimationController _ac;
  late final AnimationController _pulse;

  MatchInfo? get m => widget.match;
  bool get online => m != null;
  Side? get mySide => m == null ? null : (m!.first ? Side.red : Side.black);
  String _name(Side s) => tr(s == Side.red ? '红方' : '黑方');
  bool get _aiOn => widget.ai != null && !online;

  void _syncRecord() {
    if (!online) return;
    if (over == null) {
      _recorded = false;
    } else if (!_recorded) {
      _recorded = true;
      final Side w = !game.hasKing(Side.red)
          ? Side.black
          : (!game.hasKing(Side.black) ? Side.red : game.turn.other);
      if (!devUsed) app.recordResult(w == mySide);
    }
  }

  @override
  void initState() {
    super.initState();
    strict = widget.free ? widget.strictInit : true;
    autoMate = m != null ? m!.params['mate'] != false : widget.mate;
    _ac = AnimationController(vsync: this, duration: const Duration(milliseconds: 420))
      ..value = 1;
    _pulse = AnimationController(vsync: this, duration: const Duration(milliseconds: 2400))
      ..value = 1;
    if (_aiOn) {
      flip = widget.ai!.human == Side.black;
      WidgetsBinding.instance.addPostFrameCallback((_) => _maybeAi());
    }
    if (online) {
      flip = mySide == Side.black;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) m!.link.handler = _onNet;
      });
    }
  }

  @override
  void dispose() {
    _aiGen++;
    _ac.dispose();
    _pulse.dispose();
    if (online) {
      m!.link.handler = null;
      m!.link.close();
    }
    super.dispose();
  }

  Future<void> _maybeAi() async {
    if (!mounted || !_aiOn || over != null || _aiThinking) return;
    if (game.turn != widget.ai!.ai) return;
    final gen = ++_aiGen;
    setState(() => _aiThinking = true);
    Move? mv;
    try {
      mv = await aiStandardMove(game, widget.ai!.level);
    } catch (_) {
      mv = null;
    }
    if (!mounted || gen != _aiGen) return;
    // 等玩家那一步的移动动画播完，再让 AI 落子，避免棋子看起来“瞬移”
    while (mounted && gen == _aiGen && _ac.isAnimating) {
      await Future<void>.delayed(const Duration(milliseconds: 40));
    }
    await Future<void>.delayed(const Duration(milliseconds: 160));
    if (!mounted || gen != _aiGen) return;
    final Move? pick = (mv != null && _legalForAi(mv)) ? mv : _randomAiMove();
    setState(() {
      _aiThinking = false;
      if (pick != null) {
        final cap = game.b[pick.tr][pick.tc] != null;
        if (game.play(pick, strict: false)) _afterMove(pick, cap);
      }
    });
  }

  bool _legalForAi(Move m) {
    final p = game.b[m.fr][m.fc];
    if (p == null || p.side != widget.ai!.ai) return false;
    return game.legalMoves(m.fr, m.fc).any((x) => x.tr == m.tr && x.tc == m.tc);
  }

  Move? _randomAiMove() {
    final all = <Move>[];
    for (var r = 0; r < 10; r++) {
      for (var c = 0; c < 9; c++) {
        final p = game.b[r][c];
        if (p != null && p.side == widget.ai!.ai) all.addAll(game.legalMoves(r, c));
      }
    }
    if (all.isEmpty) return null;
    return all[Random().nextInt(all.length)];
  }

  void clearSel() {
    sr = null;
    sc = null;
    hints = [];
  }

  void _afterMove(Move mv, bool cap) {
    last = mv;
    lastCap = cap;
    clearSel();
    checkOver();
    _ac.forward(from: 0);
    if (cap) _pulse.forward(from: 0);
  }

  void _reset() {
    _aiGen++;
    _aiThinking = false;
    game.reset();
    last = null;
    lastCap = false;
    over = null;
    devUsed = false;
    clearSel();
    _ac.value = 1;
    _pulse.value = 1;
    WidgetsBinding.instance.addPostFrameCallback((_) => _maybeAi());
  }

  void _onNet(Map<String, dynamic> msg) {
    if (!mounted) return;
    final t = msg['type'];
    setState(() {
      if (t == 'move') {
        final mv = Move(msg['fr'] as int, msg['fc'] as int, msg['tr'] as int, msg['tc'] as int);
        final cap = game.b[mv.tr][mv.tc] != null;
        if (game.play(mv, strict: false)) _afterMove(mv, cap);
      } else if (t == 'dev') {
        devUsed = true;
        final mv = Move(msg['fr'] as int, msg['fc'] as int, msg['tr'] as int, msg['tc'] as int);
        final a0 = game.b[mv.fr][mv.fc];
        final t0 = game.b[mv.tr][mv.tc];
        final cap = a0 != null && t0 != null && a0.side != t0.side;
        if (game.devApply(mv)) _afterMove(mv, cap);
      } else if (t == 'restart') {
        _reset();
      } else if (t == 'closed') {
        lost = true;
      }
    });
  }

  void select(int r, int c) {
    final p = game.b[r][c];
    setState(() {
      if (p == null || (strict && p.side != game.turn) || (online && p.side != mySide)) {
        clearSel();
        return;
      }
      sr = r;
      sc = c;
      hints = strict ? game.legalMoves(r, c) : [];
    });
  }

  void checkOver() {
    for (final s in Side.values) {
      if (!game.hasKing(s)) {
        over = trf('{s}获胜', {'s': _name(s.other)});
        return;
      }
    }
    if (!strict) return;
    final t = game.turn;
    if (autoMate && game.isCheckmated(t)) {
      over = trf('{s}被绝杀，{o}获胜', {'s': _name(t), 'o': _name(t.other)});
      return;
    }
    if (!game.hasLegalMove(t)) {
      over = trf('{s}无路可走，{o}获胜', {'s': _name(t), 'o': _name(t.other)});
    }
  }

  void _devTap(int r, int c) {
    final p = game.b[r][c];
    if (sr == null) {
      if (p == null) return;
      setState(() {
        sr = r;
        sc = c;
        hints = [];
      });
      return;
    }
    if (sr == r && sc == c) {
      setState(clearSel);
      return;
    }
    final mv = Move(sr!, sc!, r, c);
    final a = game.b[mv.fr][mv.fc];
    final cap = a != null && p != null && a.side != p.side;
    if (game.devApply(mv)) {
      devUsed = true;
      if (online) {
        m!.link.send({'type': 'dev', 'fr': mv.fr, 'fc': mv.fc, 'tr': mv.tr, 'tc': mv.tc});
      }
      setState(() => _afterMove(mv, cap));
      _maybeAi();
    } else {
      setState(clearSel);
    }
  }

  void onTap(int r, int c) {
    if (over != null || lost) return;
    if (devFree && app.dev) {
      _devTap(r, c);
      return;
    }
    if (online && game.turn != mySide) return;
    if (_aiOn && (_aiThinking || game.turn != widget.ai!.human)) return;
    final p = game.b[r][c];
    if (sr != null) {
      final from = game.b[sr!][sc!];
      if (from != null && p != null && p.side == from.side) {
        select(r, c);
        return;
      }
      final mv = Move(sr!, sc!, r, c);
      final cap = p != null;
      if (game.play(mv, strict: strict)) {
        if (online) {
          m!.link.send({'type': 'move', 'fr': mv.fr, 'fc': mv.fc, 'tr': mv.tr, 'tc': mv.tc});
        }
        setState(() => _afterMove(mv, cap));
      _maybeAi();
      } else {
        setState(clearSel);
      }
      return;
    }
    select(r, c);
  }

  void undo() {
    if (_aiThinking) return;
    setState(() {
      game.undo();
      if (_aiOn && game.history.isNotEmpty && game.turn != widget.ai!.human) game.undo();
      last = game.history.isEmpty ? null : game.history.last.move;
      lastCap = false;
      over = null;
      clearSel();
      _ac.value = 1;
      _pulse.value = 1;
    });
    WidgetsBinding.instance.addPostFrameCallback((_) => _maybeAi());
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final Animation<double> enter = ModalRoute.of(context)?.animation ?? kAlwaysCompleteAnimation;
    _syncRecord();
    String msg;
    if (over != null) {
      msg = over!;
    } else if (lost) {
      msg = tr('对方已断开连接');
    } else if (online) {
      msg = tr(game.turn == mySide ? '轮到你走棋' : '等待对方走棋…');
    } else {
      msg = trf('{s}走棋', {'s': _name(game.turn)});
    }
    final base = tr(widget.free ? '自由模式' : '普通对局');
    final title = online
        ? '$base · ${tr('联机')}'
        : (_aiOn ? '$base · ${tx('对战 AI')} ${aiLevelName(widget.ai!.level)}' : base);

    return Stack(
      fit: StackFit.expand,
      children: [
        const ImageSlot(slot: 'game'),
        Scaffold(
          appBar: AppBar(title: Text(title)),
          body: SafeArea(
            child: Column(
              children: [
                Stagger(anim: enter, begin: 0.30, end: 0.62, from: const Offset(0, -0.5), child: SizedBox(
                  height: 44,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      sideTag(context, Side.black,
                          active: over == null && game.turn == Side.black,
                          mine: online && mySide == Side.black),
                      const SizedBox(width: 12),
                      sideTag(context, Side.red,
                          active: over == null && game.turn == Side.red,
                          mine: online && mySide == Side.red),
                    ],
                  ),
                )),
                Stagger(anim: enter, begin: 0.36, end: 0.68, from: const Offset(0, -0.4), child: SizedBox(
                  height: 40,
                  child: Center(
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 250),
                      transitionBuilder: (c, a) =>
                          FadeTransition(opacity: a, child: ScaleTransition(scale: a, child: c)),
                      child: _aiThinking
                          ? ThinkingLabel(
                              key: const ValueKey('thinking'),
                              color: widget.ai!.level == 4 ? const Color(0xFFFF3D3D) : cs.primary)
                          : Text(
                              msg,
                              key: ValueKey(msg),
                              style: TextStyle(
                                fontSize: 19,
                                fontWeight: FontWeight.w700,
                                color: over != null ? cs.primary : cs.onSurface,
                              ),
                            ),
                    ),
                  ),
                )),
                Expanded(
                  child: Stagger(anim: enter, begin: 0.38, end: 0.92, from: const Offset(0, 0.04), child: Center(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: AspectRatio(
                        aspectRatio: 9 / 12,
                        child: LayoutBuilder(builder: (ctx, cons) {
                          final cell = cons.maxWidth / 9;
                          return GestureDetector(
                            onTapUp: (d) {
                              var c = (d.localPosition.dx / cell).floor();
                              var r = ((d.localPosition.dy - cell) / cell).floor();
                              if (c < 0 || c > 8 || r < 0 || r > 9) return;
                              if (flip) {
                                c = 8 - c;
                                r = 9 - r;
                              }
                              onTap(r, c);
                            },
                            child: RepaintBoundary(
                              child: CustomPaint(
                                size: Size(cons.maxWidth, cons.maxHeight),
                                painter: BoardPainter(
                                    game, last, lastCap, sr, sc, hints, flip, _ac, _pulse),
                              ),
                            ),
                          );
                        }),
                      ),
                    ),
                  )),
                ),
                Stagger(anim: enter, begin: 0.55, end: 1.0, from: const Offset(0, 0.9), child: ActionBar(
                  children: [
                    if (app.dev)
                      LitToggle(
                        icon: Icons.build,
                        label: tr('自由行棋'),
                        value: devFree,
                        onChanged: (v) {
                          setState(() {
                            devFree = v;
                            clearSel();
                          });
                          if (v) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                content: Text(tr(
                                    '自由行棋：点一个棋子，再点目标格。空格=移动，对方棋子=吃掉，己方棋子=调换位置；再点一次已选棋子可取消。'))));
                          }
                        },
                      ),
                    if (!online)
                      LitButton(
                          icon: Icons.undo,
                          label: tr('悔棋'),
                          onTap: game.history.isEmpty ? null : undo),
                    LitButton(
                        icon: Icons.flip,
                        label: tr('翻转'),
                        onTap: () => setState(() => flip = !flip)),
                    if (!online || m!.isHost)
                      LitButton(
                        icon: Icons.refresh,
                        label: tr('重开'),
                        onTap: () {
                          setState(_reset);
                          if (online) m!.link.send({'type': 'restart'});
                        },
                      ),
                    if ((widget.free && !online) || app.dev)
                      LitToggle(
                        icon: Icons.rule,
                        label: tr('规则校验'),
                        value: strict,
                        onChanged: (v) => setState(() {
                          strict = v;
                          clearSel();
                        }),
                      ),
                    if (!online)
                      LitToggle(
                        icon: Icons.flag,
                        label: tr('自动判绝杀'),
                        value: autoMate,
                        enabled: strict,
                        hint: tr('需要开启规则校验后才可开启'),
                        onChanged: (v) => setState(() => autoMate = v),
                      ),
                  ],
                )),
              ],
            ),
          ),
        ),
        if (online) ...onlineBadges(context, m!.link),
      ],
    );
  }
}

class BoardPainter extends CustomPainter {
  final Game game;
  final Move? last;
  final bool lastCap;
  final int? sr, sc;
  final List<Move> hints;
  final bool flip;
  final Animation<double> anim;
  final Animation<double> pulse;

  BoardPainter(this.game, this.last, this.lastCap, this.sr, this.sc, this.hints, this.flip,
      this.anim, this.pulse)
      : super(repaint: Listenable.merge([anim, pulse]));

  List<Piece> _dead(Side s) => [
        for (final h in game.history)
          if (h.captured != null && h.captured!.side == s) h.captured!
      ];

  @override
  void paint(Canvas canvas, Size size) {
    final cell = size.width / 9;
    final top = cell;
    Offset pos(int r, int c) {
      final rr = flip ? 9 - r : r;
      final cc = flip ? 8 - c : c;
      return Offset(cell * (cc + 0.5), top + cell * (rr + 0.5));
    }

    final f = anim.value;
    final t = Curves.easeOutCubic.transform(f);
    final pv = 0.5 + 0.5 * sin(pulse.value * pi * 6);
    drawBoard(canvas, cell, top);

    final redY = flip ? 0.0 : top + cell * 10;
    final blackY = flip ? top + cell * 10 : 0.0;
    for (final s in Side.values) {
      final list = _dead(s);
      var fresh = -1;
      if (game.history.isNotEmpty) {
        final cp = game.history.last.captured;
        if (cp != null && cp.side == s) fresh = list.length - 1;
      }
      drawTray(canvas, cell, s == Side.red ? redY : blackY, s, list,
          fresh: fresh, t: t, pulse: pv);
    }

    final lm = last;
    final animating = lm != null && f < 1;
    if (lm != null) {
      final hl = Paint()
        ..color = const Color(0xFF1E88E5)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3;
      canvas.drawCircle(pos(lm.fr, lm.fc), cell * 0.46, hl);
      canvas.drawCircle(pos(lm.tr, lm.tc), cell * 0.46, hl);
    }

    for (var r = 0; r < 10; r++) {
      for (var c = 0; c < 9; c++) {
        final p = game.b[r][c];
        if (p == null) continue;
        if (animating && lm.tr == r && lm.tc == c) continue;
        drawPiece(canvas, pos(r, c), cell * 0.42, p.label,
            p.side == Side.red ? app.red : app.black);
      }
    }

    if (animating) {
      final p = game.b[lm.tr][lm.tc];
      if (p != null) {
        final ctr = Offset.lerp(pos(lm.fr, lm.fc), pos(lm.tr, lm.tc), t)!;
        drawPiece(canvas, ctr, cell * 0.42, p.label, p.side == Side.red ? app.red : app.black);
      }
      if (lastCap) {
        canvas.drawCircle(
            pos(lm.tr, lm.tc),
            cell * (0.3 + 0.7 * f),
            Paint()
              ..color = Colors.orangeAccent.withOpacity(1 - f)
              ..style = PaintingStyle.stroke
              ..strokeWidth = 4);
      }
    }

    if (sr != null && sc != null) {
      canvas.drawCircle(
          pos(sr!, sc!),
          cell * 0.47,
          Paint()
            ..color = Colors.teal
            ..style = PaintingStyle.stroke
            ..strokeWidth = 3.5);
    }

    for (final mv in hints) {
      final ctr = pos(mv.tr, mv.tc);
      if (game.b[mv.tr][mv.tc] != null) {
        canvas.drawCircle(
            ctr,
            cell * 0.47,
            Paint()
              ..color = Colors.redAccent
              ..style = PaintingStyle.stroke
              ..strokeWidth = 3);
      } else {
        canvas.drawCircle(ctr, cell * 0.12, Paint()..color = Colors.teal.withOpacity(0.8));
      }
    }
  }

  @override
  bool shouldRepaint(covariant BoardPainter oldDelegate) => true;
}
